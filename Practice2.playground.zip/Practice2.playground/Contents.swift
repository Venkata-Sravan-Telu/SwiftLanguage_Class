import UIKit

//1
var mobileBrand = "Apple"
mobileBrand = "Samsung"
print(mobileBrand)

//2
let pi=3.477
print(pi)

//3
var age:Int = 23
age = age*2
print(age)

//4
var awemessage="This is superb!"
print(awemessage)
print("awemessage")

//5
var course1 = "ios"
var course2 = "java"
print(course1,course2)
print(course1,"-",course2)

//6
print(10,20,30)
print(12.5,15)

//7
var httpError  = (errorCode : 404  , errorMessage : "Page Not Found")
print(httpError)
print(httpError.errorCode , terminator : ": ")
print(httpError.errorMessage )

//8
var name = ("John","Smith")
var fName = name.0
var lName = name.1
print(fName , terminator : ",")
print(lName)

//9
var origin = (x : 0 , y : 0)
var point = origin
print(point)
print(origin.0,origin.1)
print(origin.0,origin.1,separator: ",")
print(origin.0,",",origin.1)

//10
let city = (name : "Maryville" , population : 11000)
let ( cityName ,cityPopulation ) = (city.0 , city.1)
print(cityName)
print(cityPopulation)

//11
let groceries = ("bread","onions",11)
print(groceries.0)
print(groceries.1)
print(groceries.2)
print(type(of: groceries))

//12
var fname="Joe"
var lname="Root"
(fname,lname)=(lname,fname)
print("First name is \(fname) and last name is \(lname)")

//13
var cricketKit = ("handGloves" ,"helmet",("bat","ball"))
print(cricketKit.0)
print(cricketKit.1)
print(cricketKit.2.0)
print(cricketKit.2.1)
print(cricketKit.2)
cricketKit = ("Hand","leg",("eyes","nose"))
print(cricketKit)

//14
var number1 = (4,5)
var number2 = (4,6)
print(number1 < number2)

//15
print(4 > 5 && 8 > 3)
print(5 > 7 || 8 < 2 * 5)
print(!(5 <= 4 || 6 != 5 && 10 >= 4))

//16
var four = 4
var finalNumber = -four
print(finalNumber)

//17
var num1 = 10
var num2 = 5
print(num1/num2)

//18
var marks=45
if marks==50{
    print("The student has passed with \(marks) ")
}
else{
    print("The student has managed with \(marks)")
}

//19
var inputNumber = -10
if inputNumber>0 {
    print("\(inputNumber) is a positive number.")
}else if (inputNumber<0){
    print("\(inputNumber) is a negative number")
    if(inputNumber%2==0){
        print("\(inputNumber) is a negative even number")
    }
}else {
    print("The number  is 0")
}

//20
var stars = 65
if(stars>=90) {
    print("You are a Pro Member")
}
else if (stars>=78 && stars<90){
print("You are a Gold Member")
}
else if (stars>=65 && stars<78) {
    print("You are a VIP Member")
}
else {
    print("Default Plan")
}

//21
var random = "Hello"
print(random.count)
