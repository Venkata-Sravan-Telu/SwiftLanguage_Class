import UIKit

var greeting = "Hello, playground"
print("Hello",10,9.25,true)
print("hekk \(greeting) welcome")
print("""
    Hello
evryone
""")
print("im going to next line \rWent to next line")
var age=14
age+=2
print(age)
print("Welcome to Swift Programming")
print("Fall 2021")
print("*************")
print("Welcome to Swift Programming" , terminator : "%" )
print("Fall 2021")
print("The list of numbers are ")
print(1,2,3,4,5,6)
print("The new pattern is")
print(1,2,3,4,5,6, separator: "abc")

var number:Int = 3
print(number)
