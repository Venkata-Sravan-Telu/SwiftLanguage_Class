

import Foundation

struct data{
    var taskName=""
    var taskDetails=""
    var priority=""
    var date=""
}
