//
//  DetailViewController.swift
//  To-Do
//
//  Created by Pakalapati,Nikhil Varma on 5/4/23.
//

import UIKit

class DetailViewController: UIViewController {
    
    
    var taskN=""
    var taskD=""
    var taskDate=""
    var taskP=""
    
    @IBOutlet weak var Tn: UILabel!
    @IBOutlet weak var Details: UILabel!
    @IBOutlet weak var Prioirity: UILabel!
    
    @IBOutlet weak var Date: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
