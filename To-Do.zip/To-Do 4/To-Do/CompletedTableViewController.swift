

import UIKit

class CompletedTableViewController: UITableViewController {
    
    var completedTasks: [Task] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        
        NotificationCenter.default.addObserver(self, selector: #selector(handleTaskCompleted(notification:)), name: .taskCompleted, object: nil)
    }
    
    @objc private func handleTaskCompleted(notification: Notification) {
        if let task = notification.object as? Task {
            TaskStorage.shared.addCompletedTask(task)
            print("Completed task added: \(task.title)")
            tableView.reloadData()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tableView.reloadData()
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return TaskStorage.shared.completedTasks.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CompletedTaskCell", for: indexPath)
        let task = TaskStorage.shared.completedTasks[indexPath.row]
        cell.textLabel?.text = task.title
        return cell
    }

}
