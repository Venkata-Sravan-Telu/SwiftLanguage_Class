
import Foundation

extension Notification.Name {
    static let taskListUpdated = Notification.Name("taskListUpdated")
    static let taskDeleted = Notification.Name("taskDeleted")
    static let taskCompleted = Notification.Name("taskCompleted")
}
