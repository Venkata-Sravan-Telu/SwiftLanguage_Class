//
//  AddTaskViewController.swift
//  To-Do
//
//  Created by Telu,Venkata Sravan on 4/25/23.
//

import UIKit

struct Task {
    let title: String
    let priority: String
    let pickerViewData: String
    let textViewData: String
}


protocol AddTaskVCDelegate: AnyObject {
    func didCreateTask(_ task: Task)
}


class AddTaskViewController: UIViewController, UIPickerViewDataSource  , UIPickerViewDelegate{
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    @IBOutlet weak var titleTF: UITextField!
    @IBOutlet weak var detailsTF: UITextView!
    @IBOutlet weak var priorityPV: UIPickerView!
    
    @IBOutlet weak var dateP: UIDatePicker!
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return prior.count
    }
   
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
      return prior[row]
    }

    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
       p=prior[row]
    }
    
    weak var delegate: AddTaskVCDelegate?

    var p=""
    var prior:[String] = ["No Priority","Low Priority","Medium Priority","High Priority"]
    @IBOutlet weak var setPriorityPicker: UIPickerView!
    @IBOutlet weak var listTF: UITextField!
    @IBOutlet weak var textView: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setPriorityPicker.dataSource=self
        setPriorityPicker.delegate=self
        // Do any additional setup after loading the view.
    }
    
    @IBAction func addTask(_ sender: Any) {
            guard let taskTitle = listTF.text, !taskTitle.isEmpty else {
                let alertController = UIAlertController(title: "Error", message: "Please enter a task title.", preferredStyle: .alert)
                let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
                alertController.addAction(okAction)
                present(alertController, animated: true, completion: nil)
                return
            }

            guard let textViewData = textView.text, !textViewData.isEmpty else {
                let alertController = UIAlertController(title: "Error", message: "Please enter task details.", preferredStyle: .alert)
                let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
                alertController.addAction(okAction)
                present(alertController, animated: true, completion: nil)
                return
            }

            let taskPriority = p
            let pickerViewData = prior[setPriorityPicker.selectedRow(inComponent: 0)]
            let newTask = Task(title: taskTitle, priority: taskPriority, pickerViewData: pickerViewData, textViewData: textViewData)
            delegate?.didCreateTask(newTask)
            self.dismiss(animated: true, completion: nil)
        }

    

}
