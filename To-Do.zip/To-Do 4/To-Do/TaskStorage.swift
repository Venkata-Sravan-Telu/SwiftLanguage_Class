
import Foundation

class TaskStorage {
    static let shared = TaskStorage()

    private(set) var deletedTasks: [Task] = []
    private(set) var completedTasks: [Task] = []

    private init() {}

    func addDeletedTask(_ task: Task) {
        deletedTasks.append(task)
    }

    func addCompletedTask(_ task: Task) {
        completedTasks.append(task)
    }
}


