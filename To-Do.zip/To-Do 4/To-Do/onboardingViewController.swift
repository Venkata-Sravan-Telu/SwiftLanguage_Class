//
//  onboardingViewController.swift
//  To-Do
//
//  Created by Telu,Venkata Sravan on 4/20/23.
//

import UIKit

class onboardingViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        setupViews()
    }
    
    @IBOutlet weak var nextButtonOL: UIButton!
    
    private enum LocalConstants {
        static let cornerRadius: CGFloat = 10
    }
    
    func alreadyShown() -> Bool {
        return UserDefaults.standard.bool(forKey: Constants.Key.onboarding)
    }
    
    @IBAction func nextButtonClickedOL(_ sender: UIButton) {
        markAsSeen()
        dismiss(animated: true, completion: nil)
    }
    
    private func markAsSeen() {
        UserDefaults.standard.set(true, forKey: Constants.Key.onboarding)
    }

    fileprivate func setupViews() {
        nextButtonOL.layer.cornerRadius = LocalConstants.cornerRadius
        nextButtonOL.clipsToBounds = true
    }
    
    
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

