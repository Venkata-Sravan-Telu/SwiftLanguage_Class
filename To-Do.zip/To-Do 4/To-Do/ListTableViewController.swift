

import UIKit
import Foundation

class ListTableViewController: UITableViewController {
    
    var listTasks: [Task] = []

    override func viewDidLoad() {
        super.viewDidLoad()
       
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return listTasks.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TaskCell", for: indexPath)
        let task: Task
        task = listTasks[indexPath.row]

        cell.textLabel?.text = task.title
        return cell
    }
    
    override func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let deleteAction = UIContextualAction(style: .destructive, title: "Delete") { (action, view, completionHandler) in
            let deletedTask = self.listTasks.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .automatic)
            
            NotificationCenter.default.post(name: .taskDeleted, object: deletedTask)
            TaskStorage.shared.addDeletedTask(deletedTask)
            
            completionHandler(true)
            print("Notification posted for task: \(deletedTask.title)")
        }
        let configuration = UISwipeActionsConfiguration(actions: [deleteAction])
        configuration.performsFirstActionWithFullSwipe = false
        return configuration
    }


    override func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let completeAction = UIContextualAction(style: .normal, title: "Complete") { (_, _, completionHandler) in
            let completedTask = self.listTasks[indexPath.row]
            TaskStorage.shared.addCompletedTask(completedTask)
            print("Completed task added: \(completedTask.title)")

            // Remove the task from listTasks and update the table view
            self.listTasks.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .automatic)
            
            completionHandler(true)
        }
        completeAction.backgroundColor = .systemGreen

        let configuration = UISwipeActionsConfiguration(actions: [completeAction])
        configuration.performsFirstActionWithFullSwipe = false
        return configuration
    }


    
    @IBAction func addTaskTapped(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let AddTaskVC = storyboard.instantiateViewController(withIdentifier: "AddTaskViewController") as? AddTaskViewController {
            AddTaskVC.delegate = self
            self.present(AddTaskVC, animated: true, completion: nil)
    }
    }
}

extension ListTableViewController: AddTaskVCDelegate {
    func didCreateTask(_ task: Task) {
        listTasks.append(task)
        tableView.reloadData()
        
        // Post a notification when a new task is created
        NotificationCenter.default.post(name: .taskListUpdated, object: nil)
       // print("New task added")
    }
}
