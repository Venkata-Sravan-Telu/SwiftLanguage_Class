
import UIKit
class DeleatedTableViewController: UITableViewController {
    
    var deletedTasks: [Task] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        NotificationCenter.default.addObserver(self, selector: #selector(handleTaskDeleted(notification:)), name: .taskDeleted, object: nil)
    }
    
    @objc private func handleTaskDeleted(notification: Notification) {
        if let task = notification.object as? Task {
            TaskStorage.shared.addDeletedTask(task)
            deletedTasks = TaskStorage.shared.deletedTasks
            print("Deleted task added to deletedTasks array.")
        }
    }

    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        deletedTasks = TaskStorage.shared.deletedTasks
        tableView.reloadData()
    }
    

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return deletedTasks.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "DeletedTaskCell", for: indexPath)
        let task = deletedTasks[indexPath.row]
        cell.textLabel?.text = task.title
        return cell
    }

}

